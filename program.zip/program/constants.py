from decouple import config

# ===== Loop / Cadencia =====
EXIT_CHECK_SECONDS = 30       # cada cuánto evalúas exits (segundos)
KPI_SECONDS = 600             # cada cuánto mandas KPIs (10 min)
BATCH_OPEN_TRADES = 3         # abrir N trades y luego forzar revisión
MAX_OPEN_TRADES = 8           # hard cap de pares abiertos

# ===== Exit rules =====
USE_MIN_PROFIT_TP = True
# MIN_PROFIT_USD y MIN_PROFIT_PCT son el beneficio NETO mínimo DESPUÉS de fees.
# La lógica calcula automáticamente fees pagadas en apertura + estimado de cierre
# y los suma al umbral, así que estos valores son la "ganancia real mínima".
MIN_PROFIT_PCT = 0.0015   # 0.15% del notional como ganancia neta mínima
MIN_PROFIT_USD = 3.0      # o al menos $3 neto — lo que sea mayor
DROP_STALE_RECORDS = True

USE_Z_TP = True
Z_TP = 0.7           # cierra cuando abs(z) vuelve a ≤ 0.7 (casi media)

USE_Z_SL = True
Z_SL_DELTA = 1.5     # SL cuando abs(z_now) >= abs(z_entry) + 1.5
                     # Ej: entrada z=1.5 → SL en z=3.0

# TIME_STOP desactivado por decisión del usuario:
# se confía en Z-SL y Hard SL monetario para todo cierre por riesgo.
USE_TIME_STOP = False
TIME_STOP_HOURS = 24   # dejado aquí por si se reactiva (no se usa si USE_TIME_STOP=False)

# ===== TP Confirmation =====
# El usuario eligió "doble confirmación sin hold mínimo":
# - No hay tiempo mínimo de tenencia antes de TP
# - Z debe estar en zona TP durante 2 checks consecutivos (~60s con EXIT_CHECK_SECONDS=30)
# - Esto evita cierres por velas de ruido de 1-2 minutos
TP_CONFIRM_CHECKS = 2        # checks consecutivos requeridos en zona TP
MIN_HOLD_MINUTES_FOR_TP = 0  # 0 = sin restricción de tiempo mínimo

# ===== Risk-Off =====
RISK_OFF_ENABLED = True

# Disparadores de risk-off
RISK_OFF_FREE_COLLATERAL_TRIGGER = 7000   # si free collateral < esto → risk-off

# IMPORTANTE: igual a MAX_OPEN_TRADES. Si fuera menor, risk-off dispararía
# antes de llegar al hard cap y cerraría posiciones sanas.
RISK_OFF_FORCE_IF_OPEN_TRADES_GE = 8     # igualado a MAX_OPEN_TRADES

# Edad mínima antes de que risk-off pueda cerrar un par.
# 0.5h = 30 minutos. Protege aperturas muy recientes de cierres forzados inmediatos,
# pero permite cerrar posiciones jóvenes que ya estén en pérdida real.
RISK_OFF_MIN_AGE_HOURS = 0.5

# ===== Risk-Off Score Weights =====
# El "peor par" se define principalmente por:
#   1. Pérdida monetaria real (unrealized negativo) — peso mayor
#   2. Divergencia del z-score — señal de tesis rota
#   3. Stale bonus (solo si > 24h abierto) — calculado inline en func_risk_off.py
#
# ANTES: W_AGE=1.0 dominaba → el par más viejo siempre era "peor", independientemente
# de su PnL. INCORRECTO: un par sano y viejo no debe cerrarse solo por ser viejo.
# AHORA: edad no tiene peso; solo pérdida + divergencia de z.
RISK_SCORE_W_AGE = 0.0          # eliminado: edad no determina peor par
RISK_SCORE_W_ABS_Z = 5.0        # z-divergence es la segunda señal más importante
RISK_SCORE_W_UNREAL_PNL = 0.15  # $1 de pérdida ≈ 0.15 puntos de score
                                  # (antes era 0.001 — la pérdida no importaba!)

# Hard Stop-Loss monetario (en func_exit_pairs.py)
# Con $2000 notional por par: max($35, 0.6%*$2000=$12) = $35
# = 1.75% de pérdida máxima antes de forzar cierre
HARD_SL_USD = 35.0
HARD_SL_PCT = 0.006

# SELECT MODE
MODE = "DEVELOPMENT"

# ===== Pre-COMMIT Liquidity Gate =====
# Skip COMMIT if bid-ask spread on either leg exceeds this threshold.
# Prevents fee waste from flattening when one leg fills but the other can't.
#
# Testnet (DEVELOPMENT): 200 bps — orderbooks are intentionally thin,
#   spreads of 50-250 bps are normal and don't predict mainnet fill quality.
#   Still blocks truly illiquid outliers (ATH-USD at 257 bps, etc.)
#
# Mainnet (PRODUCTION): 25 bps — liquid pairs have 1-20 bps.
#   Anything wider predicts partial fills on one leg.
#
# Set to 0 to disable entirely.
MAX_ENTRY_SPREAD_BPS = 200 if MODE == "DEVELOPMENT" else 25

# Close all open positions and orders
# Ponlo en True sólo si quieres limpiar posiciones al arrancar.
# Con bot_agents.json vacío y sin posiciones stuck, dejarlo en False.
ABORT_ALL_POSITIONS = False

# Find cointegrated pairs
FIND_COINTEGRATED = False

# Auto-refresh cointegration: regenerate cointegrated_pairs.csv if the file
# is older than this many hours, even when FIND_COINTEGRATED = False.
# Set to 0 to disable auto-refresh (not recommended — stale pairs are dangerous).
COINTEGRATION_REFRESH_HOURS = 24

# Manage exits
MANAGE_EXITS = True

# Place Trades
PLACE_TRADES = True

# Resolution
RESOLUTION = "1HOUR"

# Status Window (days)
WINDOW = 21

# Thresholds - Opening
MAX_HALF_LIFE = 24
                       # El exit por Z_SL y HARD_SL gestiona el riesgo de tardanza
ZSCORE_THRESH = 1.5
USD_PER_TRADE = 1000
USD_MIN_COLLATERAL = 7000

# Thresholds - Closing
CLOSE_AT_ZSCORE_CROSS = True

# Wallet Address
WALLET_ADDRESS = "dydx1napkzyjp3rauk5p787r9sfhvs74r8e357a30n5"

# WALLET PRIVATE KEY
API_KEY = config("API_KEY")

# URL ADDRESS TESTNET
NODE_TESTNET = "test-dydx-grpc.kingnodes.com"
INDEXER_TESTNET = "https://indexer.v4testnet.dydx.exchange"
WEBSOCKET_TESTNET = "wss://indexer.v4testnet.dydx.exchange/v4/ws"

# URL ADDRESS MAINNET
NODE_MAINNET = ""
INDEXER_MAINNET = ""
WEBSOCKET_MAINNET = ""

# URL Selection
NODE = NODE_MAINNET if MODE == "PRODUCTION" else NODE_TESTNET
INDEXER = INDEXER_MAINNET if MODE == "PRODUCTION" else INDEXER_TESTNET
WEBSOCKET = WEBSOCKET_MAINNET if MODE == "PRODUCTION" else WEBSOCKET_TESTNET

UNMANAGED_CLOSE_MAX_ATTEMPTS = 2
UNMANAGED_ALERT_COOLDOWN_SECONDS = 300

# Markets con posición atascada que el abort no puede cerrar en testnet.
# Ignorarlos evita que bloqueen entradas indefinidamente.
# Vaciar cuando se cierren manualmente desde la UI de dYdX.
UNMANAGED_IGNORE_MARKETS = {"LDO-USD", "COMP-USD", "STX-USD"}
