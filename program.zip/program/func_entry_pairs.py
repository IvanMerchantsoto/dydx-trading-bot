from func_messaging import send_message
from constants import ZSCORE_THRESH, USD_PER_TRADE, USD_MIN_COLLATERAL, MAX_OPEN_TRADES, WINDOW
from func_utils import format_number
from func_public import get_candles_recent
from func_cointegration import calculate_zscore, CSV_PATH as COINT_CSV_PATH
from datetime import datetime, timezone
from constants import WALLET_ADDRESS
from func_bot_agent import BotAgent
from func_logging import log_event

import pandas as pd
import json
import os
import math
import uuid

JSON_PATH = os.path.join(os.path.dirname(__file__), "bot_agents.json")

# ── Pair-level failure cooldown ───────────────────────────────────────────────
# Si un par falla PAIR_FAIL_COOLDOWN_THRESHOLD veces seguidas (fills=0 o partial
# en ambas legs), se marca en cooldown por PAIR_FAIL_COOLDOWN_HOURS horas.
# Esto evita spamear el mismo par ilíquido en cada ciclo.
PAIR_FAIL_COOLDOWN_PATH = os.path.join(os.path.dirname(__file__), "pair_fail_cooldowns.json")
PAIR_FAIL_COOLDOWN_THRESHOLD = 3    # fallos consecutivos antes de cooldown
PAIR_FAIL_COOLDOWN_HOURS = 4.0      # horas de cooldown tras threshold
PAIR_FAIL_RESET_ON_SUCCESS = True   # resetear contador si hay LIVE


def _pair_key(m1, m2):
    return "/".join(sorted([str(m1), str(m2)]))


def _load_pair_fails():
    try:
        with open(PAIR_FAIL_COOLDOWN_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_pair_fails(data):
    tmp = PAIR_FAIL_COOLDOWN_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, PAIR_FAIL_COOLDOWN_PATH)


def _is_pair_in_fail_cooldown(m1, m2):
    data = _load_pair_fails()
    key = _pair_key(m1, m2)
    rec = data.get(key)
    if not rec:
        return False
    count = rec.get("consecutive_fails", 0)
    if count < PAIR_FAIL_COOLDOWN_THRESHOLD:
        return False
    ts_str = rec.get("last_fail_ts", "")
    try:
        last_fail = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        age_h = (datetime.now(timezone.utc) - last_fail).total_seconds() / 3600.0
        if age_h >= PAIR_FAIL_COOLDOWN_HOURS:
            # Cooldown expired — reset counter
            data[key] = {"consecutive_fails": 0, "last_fail_ts": ts_str}
            _save_pair_fails(data)
            return False
        return True
    except Exception:
        return False


def _record_pair_fail(m1, m2):
    data = _load_pair_fails()
    key = _pair_key(m1, m2)
    rec = data.get(key, {"consecutive_fails": 0})
    rec["consecutive_fails"] = int(rec.get("consecutive_fails", 0)) + 1
    rec["last_fail_ts"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    data[key] = rec
    _save_pair_fails(data)
    return rec["consecutive_fails"]


def _record_pair_success(m1, m2):
    if not PAIR_FAIL_RESET_ON_SUCCESS:
        return
    data = _load_pair_fails()
    key = _pair_key(m1, m2)
    if key in data:
        data[key] = {"consecutive_fails": 0, "last_fail_ts": data[key].get("last_fail_ts", "")}
        _save_pair_fails(data)


def _sf(x, d=0.0):
    """Safe float conversion."""
    try:
        return float(x)
    except Exception:
        return d


async def _get_subaccount(indexer):
    resp = await indexer.account.get_subaccount(WALLET_ADDRESS, 0)
    return resp.get("subaccount", {}) or {}


async def _get_live_markets_with_position(indexer):
    """Return a set of markets that currently have a non-zero open position."""
    sub = await _get_subaccount(indexer)
    positions = sub.get("openPerpetualPositions", {}) or sub.get("perpetualPositions", {}) or {}
    live = set()
    for m, p in positions.items():
        if abs(_sf(p.get("size"))) > 0:
            live.add(m)
    return live


def _load_open_pairs_from_json():
    try:
        with open(JSON_PATH, "r") as f:
            data = json.load(f)
        return data if data else []
    except Exception:
        return []


def _count_open_pairs_from_json():
    return len(_load_open_pairs_from_json())


async def open_positions(node, indexer, wallet, max_new_trades=1):
    """
    Entry manager — original simple logic restored.
    Cap comes from bot_agents.json count (fast, no reconcile gate).
    """
    opened_count = 0

    # 1) Hard cap from JSON
    open_pairs = _count_open_pairs_from_json()
    if open_pairs >= MAX_OPEN_TRADES:
        print(f"[ENTRY] MAX_OPEN_TRADES reached ({open_pairs}/{MAX_OPEN_TRADES}).")
        return 0

    # 2) Optional collateral gate (best-effort)
    try:
        sub = await _get_subaccount(indexer)
        free_collateral = _sf(sub.get("freeCollateral"))
        if free_collateral and free_collateral < float(USD_MIN_COLLATERAL):
            print(f"[ENTRY] Free collateral ${free_collateral:,.2f} < min ${USD_MIN_COLLATERAL:,.2f}.")
            return 0
    except Exception:
        pass

    # 3) Live markets with a position -> avoid duplicating legs
    live_markets = await _get_live_markets_with_position(indexer)

    # 4) Load cointegrated pairs (absolute path)
    if not os.path.exists(COINT_CSV_PATH):
        print(f"[ENTRY] cointegrated_pairs.csv not found. Run FIND_COINTEGRATED=True first.")
        return 0
    df = pd.read_csv(COINT_CSV_PATH)

    # 5) Market metadata
    markets_response = await indexer.markets.get_perpetual_markets()
    markets = markets_response.get("markets", {}) or {}

    # 6) Load existing open pairs state
    bot_agents = _load_open_pairs_from_json()

    def get_safe_min_size(m_name):
        m_data = markets.get(m_name, {})
        val = m_data.get("minOrderSize") or m_data.get("stepSize")
        return float(val) if val else 0.0

    MAX_PRICE_RATIO = 50.0

    for _, row in df.iterrows():

        if opened_count >= max_new_trades:
            break
        if open_pairs >= MAX_OPEN_TRADES:
            break

        base_market = row["base_market"]
        quote_market = row["quote_market"]
        hedge_ratio = float(row["hedge_ratio"])
        half_life = row.get("half_life")

        if base_market not in markets or quote_market not in markets:
            log_event({"type": "signal_skip", "reason": "invalid_market",
                       "base": base_market, "quote": quote_market})
            continue
        if base_market in live_markets or quote_market in live_markets:
            continue

        # Skip pairs in failure cooldown (too many consecutive fill failures)
        if _is_pair_in_fail_cooldown(base_market, quote_market):
            log_event({"type": "signal_skip", "reason": "pair_fail_cooldown",
                       "base": base_market, "quote": quote_market})
            continue

        try:
            base_price = float(markets[base_market]["oraclePrice"])
            quote_price = float(markets[quote_market]["oraclePrice"])
            min_base = get_safe_min_size(base_market)
            min_quote = get_safe_min_size(quote_market)
            base_step = markets[base_market]["stepSize"]
            quote_step = markets[quote_market]["stepSize"]
            tick_base = markets[base_market]["tickSize"]
        except Exception:
            continue

        price_ratio = max(base_price, quote_price) / max(1e-12, min(base_price, quote_price))
        if price_ratio > MAX_PRICE_RATIO:
            continue

        series_1 = await get_candles_recent(indexer, base_market)
        series_2 = await get_candles_recent(indexer, quote_market)

        if not (len(series_1) > 0 and len(series_1) == len(series_2)):
            continue

        spread = series_1 - (hedge_ratio * series_2)

        try:
            z_score = float(calculate_zscore(spread).values.tolist()[-1])
        except Exception:
            continue

        if abs(z_score) < ZSCORE_THRESH:
            continue

        spread_s = pd.Series(spread)
        if len(spread_s) < WINDOW + 1:
            continue

        spread_last = float(spread_s.iloc[-1])
        spread_mean_prev_s = spread_s.rolling(WINDOW).mean().shift(1)
        spread_mean_prev = float(spread_mean_prev_s.iloc[-1])

        if not math.isfinite(spread_mean_prev):
            continue

        spread_dev = abs(spread_last - spread_mean_prev)

        base_quantity = USD_PER_TRADE / base_price
        quote_quantity = USD_PER_TRADE / quote_price
        approx_spread_usd = spread_dev * min(base_quantity, quote_quantity)

        base_side = "BUY" if z_score < 0 else "SELL"
        quote_side = "BUY" if z_score > 0 else "SELL"

        base_size_fmt = format_number(base_quantity, base_step)
        quote_size_fmt = format_number(quote_quantity, quote_step)

        failsafe_p = base_price * (1.02 if base_side == "BUY" else 0.98)
        accept_failsafe_base_price = format_number(failsafe_p, tick_base)

        if float(base_size_fmt) < min_base or float(quote_size_fmt) < min_quote:
            continue

        trace_id = uuid.uuid4().hex[:10]

        log_event({
            "type": "entry_signal",
            "trace_id": trace_id,
            "base": base_market,
            "quote": quote_market,
            "z": z_score,
            "spread_dev": spread_dev,
            "approx_spread_usd": approx_spread_usd,
            "base_side": base_side,
            "quote_side": quote_side,
            "base_price": base_price,
            "quote_price": quote_price,
            "base_size": float(base_size_fmt),
            "quote_size": float(quote_size_fmt),
            "half_life": half_life,
            "hedge_ratio": hedge_ratio,
        })

        print(f"[ENTRY] Opening trade for {base_market} and {quote_market}...")

        bot_agent = BotAgent(
            node,
            indexer,
            market_1=base_market,
            market_2=quote_market,
            base_side=base_side,
            base_size=base_size_fmt,
            base_price=base_price,
            quote_side=quote_side,
            quote_size=quote_size_fmt,
            quote_price=quote_price,
            accept_failsafe_base_price=accept_failsafe_base_price,
            z_score=z_score,
            half_life=half_life,
            hedge_ratio=hedge_ratio,
            trace_id=trace_id,
            intended_usd_per_trade=USD_PER_TRADE,
        )

        bot_open_dict = await bot_agent.open_trades(wallet)

        # Always log result
        if isinstance(bot_open_dict, dict):
            log_event({
                "type": "entry_result",
                "trace_id": trace_id,
                "base": base_market,
                "quote": quote_market,
                "pair_status": bot_open_dict.get("pair_status"),
                "comments": bot_open_dict.get("comments"),
                "order_id_m1": bot_open_dict.get("order_id_m1"),
                "order_id_m2": bot_open_dict.get("order_id_m2"),
                "filled_usd_1": _sf(bot_open_dict.get("filled_usd_1")),
                "filled_usd_2": _sf(bot_open_dict.get("filled_usd_2")),
                "fee_1": _sf(bot_open_dict.get("fee_1")),
                "fee_2": _sf(bot_open_dict.get("fee_2")),
            })

        # Save LIVE
        if isinstance(bot_open_dict, dict) and bot_open_dict.get("pair_status") == "LIVE":
            now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            bot_open_dict["opened_at"] = bot_open_dict.get("opened_at") or now_iso
            bot_open_dict["side_1"] = bot_open_dict.get("side_1") or base_side
            bot_open_dict["side_2"] = bot_open_dict.get("side_2") or quote_side
            bot_open_dict["price_1"] = bot_open_dict.get("price_1") or base_price
            bot_open_dict["price_2"] = bot_open_dict.get("price_2") or quote_price
            bot_open_dict["size_1"] = bot_open_dict.get("size_1") or _sf(bot_open_dict.get("filled_size_1"), _sf(base_size_fmt))
            bot_open_dict["size_2"] = bot_open_dict.get("size_2") or _sf(bot_open_dict.get("filled_size_2"), _sf(quote_size_fmt))

            bot_agents.append(bot_open_dict)
            with open(JSON_PATH, "w") as f:
                json.dump(bot_agents, f, indent=2)

            opened_count += 1
            open_pairs += 1
            live_markets.add(base_market)
            live_markets.add(quote_market)

            # Reset failure counter for this pair
            _record_pair_success(base_market, quote_market)

            print(f"[ENTRY] Trade LIVE: {base_market} {base_side} / {quote_market} {quote_side}")

            filled_usd_1 = _sf(bot_open_dict.get("filled_usd_1"))
            filled_usd_2 = _sf(bot_open_dict.get("filled_usd_2"))
            fee_1 = _sf(bot_open_dict.get("fee_1"))
            fee_2 = _sf(bot_open_dict.get("fee_2"))
            fee_estimated = bot_open_dict.get("fee_1_estimated") or bot_open_dict.get("fee_2_estimated")
            total_fees = fee_1 + fee_2
            residual = _sf(bot_open_dict.get("residual_usd"))
            z = _sf(bot_open_dict.get("z_score"))
            hl = bot_open_dict.get("half_life")
            notional = filled_usd_1 + filled_usd_2
            fee_label = "~est" if fee_estimated else "real"

            send_message(
                f"TRADE LIVE\n"
                f"{base_market} {base_side} / {quote_market} {quote_side}\n"
                f"Notional: ${notional:,.2f} (m1=${filled_usd_1:,.2f}, m2=${filled_usd_2:,.2f})\n"
                f"Fees ({fee_label}): ${total_fees:.4f}\n"
                f"Residual: ${residual:.2f}\n"
                f"Z-score: {z:.3f} | Half-life: {hl}h"
            )
            continue

        # SKIPPED (e.g. spread too wide before COMMIT) — no MARKET orders were
        # placed, no fees paid, no exposure to check. Just move on quietly.
        if isinstance(bot_open_dict, dict) and bot_open_dict.get("pair_status") == "SKIPPED":
            skip_reason = bot_open_dict.get("comments", "")
            log_event({
                "type": "entry_skipped",
                "trace_id": trace_id,
                "base": base_market,
                "quote": quote_market,
                "reason": skip_reason,
            })
            continue

        # Not LIVE -> check for orphan exposure
        try:
            live_now = await _get_live_markets_with_position(indexer)
            orphan = (base_market in live_now) or (quote_market in live_now)
        except Exception:
            orphan = False

        if orphan and isinstance(bot_open_dict, dict):
            bot_open_dict["pair_status"] = "ORPHAN"
            bot_open_dict["needs_reconcile"] = True
            bot_open_dict["opened_at"] = bot_open_dict.get("opened_at") or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            bot_agents.append(bot_open_dict)
            with open(JSON_PATH, "w") as f:
                json.dump(bot_agents, f, indent=2)
            send_message(f"⚠️ ORPHAN: {base_market}/{quote_market}. Guardado para cleanup.")
            log_event({
                "type": "orphan_saved",
                "trace_id": trace_id,
                "base": base_market,
                "quote": quote_market,
            })
            # Orphan counts as a fill failure → increment fail counter
            fail_count = _record_pair_fail(base_market, quote_market)
            if fail_count >= PAIR_FAIL_COOLDOWN_THRESHOLD:
                log_event({"type": "pair_fail_cooldown_set", "base": base_market,
                           "quote": quote_market, "consecutive_fails": fail_count,
                           "cooldown_hours": PAIR_FAIL_COOLDOWN_HOURS})
        else:
            reason = bot_open_dict.get("comments", "Unknown") if isinstance(bot_open_dict, dict) else "Unknown"
            print(f"[ENTRY] Trade FAILED for {base_market}/{quote_market}. Reason: {reason}")

            # FAILED with actual fills (partial entry) counts as a fill failure
            if isinstance(bot_open_dict, dict):
                f1 = _sf(bot_open_dict.get("filled_usd_1"))
                f2 = _sf(bot_open_dict.get("filled_usd_2"))
                # Only count as fail if one leg filled but the other didn't
                # (liquidity issue), not if both were zero (signal issue)
                one_leg_filled = (f1 > 0) != (f2 > 0)
                if one_leg_filled:
                    fail_count = _record_pair_fail(base_market, quote_market)
                    if fail_count >= PAIR_FAIL_COOLDOWN_THRESHOLD:
                        log_event({"type": "pair_fail_cooldown_set", "base": base_market,
                                   "quote": quote_market, "consecutive_fails": fail_count,
                                   "cooldown_hours": PAIR_FAIL_COOLDOWN_HOURS})

    print("[ENTRY] Entry scan completed.")
    if opened_count > 0:
        print(f"[ENTRY] {opened_count} new pairs opened this batch.")

    return opened_count
