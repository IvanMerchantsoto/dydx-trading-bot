import asyncio
import json
import os
import random

from dydx_v4_client import MAX_CLIENT_ID, OrderFlags
from dydx_v4_client.indexer.rest.constants import OrderType
from dydx_v4_client.node.market import Market
from dydx_v4_client.wallet import Wallet
from v4_proto.dydxprotocol.clob.order_pb2 import Order

from constants import API_KEY, WALLET_ADDRESS
from func_logging import log_event


# ---------------------------------------------------------------------------
# Fee constants
# ---------------------------------------------------------------------------

# dYdX v4 taker fee rate (0.05%). Used as fallback when indexer doesn't
# return fee data (common on testnet). Both legs are taker (MARKET IOC).
TAKER_FEE_BPS = 0.0005


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sf(x, d=0.0):
    try:
        return float(x)
    except Exception:
        return d


async def _ensure_wallet(node, wallet):
    if wallet is not None:
        return wallet
    return await Wallet.from_mnemonic(node, API_KEY.strip(), WALLET_ADDRESS.strip())


def _to_dydx_side(side: str):
    if str(side).upper() == "BUY":
        return Order.Side.SIDE_BUY
    return Order.Side.SIDE_SELL


async def _get_market_obj_and_oracle(indexer, market: str):
    m_data = await indexer.markets.get_perpetual_markets(market)
    market_data = m_data["markets"][market]
    oracle_price = _sf(market_data.get("oraclePrice"))
    market_obj = Market(market_data)
    return market_obj, oracle_price, market_data


# ---------------------------------------------------------------------------
# Position reconciliation helpers
# ---------------------------------------------------------------------------

async def get_subaccount_positions(indexer):
    try:
        resp = await indexer.account.get_subaccount(WALLET_ADDRESS.strip(), 0)
        sub = resp.get("subaccount", {}) or {}
        positions = sub.get("openPerpetualPositions", {}) or sub.get("perpetualPositions", {}) or {}
        return positions
    except Exception:
        return {}


async def get_market_position_size(indexer, market: str) -> float:
    positions = await get_subaccount_positions(indexer)
    pos = positions.get(market, {}) or {}
    return _sf(pos.get("size", 0.0))


async def get_positions_snapshot(indexer, markets):
    snap = {}
    positions = await get_subaccount_positions(indexer)
    for m in markets:
        pos = positions.get(m, {}) or {}
        snap[m] = _sf(pos.get("size", 0.0))
    return snap


async def reconcile_positions(indexer, market_1: str, market_2: str):
    snap = await get_positions_snapshot(indexer, [market_1, market_2])
    return {
        "market_1": market_1,
        "market_2": market_2,
        "pos_1": _sf(snap.get(market_1, 0.0)),
        "pos_2": _sf(snap.get(market_2, 0.0)),
    }


# ---------------------------------------------------------------------------
# Orders / status
# ---------------------------------------------------------------------------

async def check_order_status(indexer, client_id):
    await asyncio.sleep(1.5)
    try:
        response = await indexer.account.get_subaccount_orders(
            address=WALLET_ADDRESS.strip(),
            subaccount_number=0,
        )

        if response is None:
            return "UNKNOWN"

        orders = response if isinstance(response, list) else response.get("orders", [])
        for order in orders:
            if str(order.get("clientId")) == str(client_id):
                return order.get("status")
        return "NOT_FOUND"
    except Exception as e:
        print(f"Error in Indexer: {e}")
        return "FAILED"


async def cancel_order_by_client_id(node, client_id: str):
    cid = str(client_id)

    try:
        if hasattr(node, "cancel_order"):
            res = node.cancel_order(order_id=cid)
            if asyncio.iscoroutine(res):
                await res
            return True
    except Exception as e:
        print(f"[CANCEL] node.cancel_order failed client_id={cid}: {e}")

    try:
        priv = getattr(node, "private", None)
        if priv is not None and hasattr(priv, "cancel_order"):
            res = priv.cancel_order(order_id=cid)
            if asyncio.iscoroutine(res):
                await res
            return True
    except Exception as e:
        print(f"[CANCEL] node.private.cancel_order failed client_id={cid}: {e}")

    for attr in ("clob", "orders", "order", "private_client"):
        try:
            obj = getattr(node, attr, None)
            if obj is not None and hasattr(obj, "cancel_order"):
                res = obj.cancel_order(order_id=cid)
                if asyncio.iscoroutine(res):
                    await res
                return True
        except Exception as e:
            print(f"[CANCEL] node.{attr}.cancel_order failed client_id={cid}: {e}")

    print(f"[CANCEL] No cancel method found for client_id={cid}.")
    return False


# ---------------------------------------------------------------------------
# Order placement
# ---------------------------------------------------------------------------

async def place_market_order(
    node,
    indexer,
    wallet,
    market,
    side,
    size,
    price,  # kept for backwards compatibility
    reduce_only,
    time_in_force_type,
):
    try:
        wallet = await _ensure_wallet(node, wallet)
        market_obj, oracle_price, _mdata = await _get_market_obj_and_oracle(indexer, market)
        dydx_side = _to_dydx_side(side)

        if str(side).upper() == "BUY":
            execution_price = float(oracle_price * 1.05)
        else:
            execution_price = float(oracle_price * 0.95)

        client_id = random.randint(0, MAX_CLIENT_ID)
        order_id = market_obj.order_id(
            WALLET_ADDRESS.strip(), 0, client_id, OrderFlags.SHORT_TERM
        )

        current_block = await node.latest_block_height()

        placed_order = market_obj.order(
            order_id=order_id,
            order_type=OrderType.MARKET,
            post_only=False,
            side=dydx_side,
            size=float(size),
            price=execution_price,
            time_in_force=time_in_force_type,
            reduce_only=bool(reduce_only),
            good_til_block=current_block + 20,
        )

        log_event({
            "type": "tx_market",
            "side": str(side).upper(),
            "market": market,
            "size": float(size),
            "oracle": oracle_price,
            "exec_price": execution_price,
            "reduce_only": bool(reduce_only),
        }, print_terminal=False)

        tx = await node.place_order(wallet=wallet, order=placed_order)
        wallet.sequence += 1

        return {
            "order": {"id": str(client_id), "status": "PENDING", "market": market},
            "tx_hash": getattr(tx, "tx_hash", "unknown"),
        }

    except Exception as e:
        print(f"[MARKET] Error enviando orden: {e}")
        log_event({
            "type": "order_error",
            "stage": "market",
            "market": market,
            "side": str(side).upper(),
            "size": _sf(size),
            "reduce_only": bool(reduce_only),
            "error": str(e),
        })
        return None


async def place_limit_order(
    node,
    indexer,
    wallet,
    market,
    side,
    size,
    limit_price,
    reduce_only=False,
    post_only=True,
    time_in_force_type=None,
    good_til_blocks=40,
):
    try:
        wallet = await _ensure_wallet(node, wallet)
        market_obj, oracle_price, _mdata = await _get_market_obj_and_oracle(indexer, market)
        dydx_side = _to_dydx_side(side)

        client_id = random.randint(0, MAX_CLIENT_ID)
        order_id = market_obj.order_id(
            WALLET_ADDRESS.strip(), 0, client_id, OrderFlags.SHORT_TERM
        )

        current_block = await node.latest_block_height()

        if time_in_force_type is None:
            time_in_force_type = getattr(Order.TimeInForce, "TIME_IN_FORCE_GTT", None) or getattr(
                Order.TimeInForce, "TIME_IN_FORCE_IOC"
            )

        placed_order = market_obj.order(
            order_id=order_id,
            order_type=OrderType.LIMIT,
            post_only=bool(post_only),
            side=dydx_side,
            size=float(size),
            price=float(limit_price),
            time_in_force=time_in_force_type,
            reduce_only=bool(reduce_only),
            good_til_block=current_block + int(good_til_blocks),
        )

        log_event({
            "type": "tx_limit",
            "side": str(side).upper(),
            "market": market,
            "size": float(size),
            "limit_price": float(limit_price),
            "oracle": oracle_price,
            "reduce_only": bool(reduce_only),
            "post_only": bool(post_only),
            "good_til_blocks": int(good_til_blocks),
        }, print_terminal=False)

        tx = await node.place_order(wallet=wallet, order=placed_order)
        wallet.sequence += 1

        return {
            "order": {"id": str(client_id), "status": "PENDING", "market": market},
            "tx_hash": getattr(tx, "tx_hash", "unknown"),
        }

    except Exception as e:
        print(f"[LIMIT] Error enviando orden: {e}")
        log_event({
            "type": "order_error",
            "stage": "limit",
            "market": market,
            "side": str(side).upper(),
            "size": _sf(size),
            "limit_price": _sf(limit_price),
            "reduce_only": bool(reduce_only),
            "post_only": bool(post_only),
            "error": str(e),
        })
        return None


# ---------------------------------------------------------------------------
# Fill details with broad fallback
# ---------------------------------------------------------------------------

async def get_real_fill_details(indexer, client_id, market, max_fill_lookback=200):
    cid = str(client_id)

    def _extract_cid(obj):
        return str(
            obj.get("clientId")
            or obj.get("client_id")
            or obj.get("orderClientId")
            or obj.get("order_client_id")
            or ""
        )

    def _extract_fee(fill):
        return (
            _sf(fill.get("fee"))
            or _sf(fill.get("feeAmount"))
            or _sf(fill.get("feeUsd"))
            or 0.0
        )

    await asyncio.sleep(1.2)

    fills_candidates = []
    try:
        fills_resp = await indexer.account.get_subaccount_fills(
            address=WALLET_ADDRESS.strip(),
            subaccount_number=0,
            ticker=market,
            limit=max_fill_lookback,
        )
        fills = fills_resp if isinstance(fills_resp, list) else fills_resp.get("fills", [])
        fills_candidates.extend(fills)
    except Exception:
        pass

    try:
        fills_resp = await indexer.account.get_subaccount_fills(
            address=WALLET_ADDRESS.strip(),
            subaccount_number=0,
            limit=max_fill_lookback,
        )
        fills = fills_resp if isinstance(fills_resp, list) else fills_resp.get("fills", [])
        fills_candidates.extend(fills)
    except Exception:
        pass

    matched_fills = [f for f in fills_candidates if _extract_cid(f) == cid]

    if matched_fills:
        total_size = 0.0
        total_usd = 0.0
        total_fee = 0.0
        liquidity = None

        for fill in matched_fills:
            size = _sf(fill.get("size") or fill.get("filledSize") or fill.get("amount"))
            price = _sf(fill.get("price") or fill.get("fillPrice"))
            total_size += size
            total_usd += size * price
            total_fee += _extract_fee(fill)
            liquidity = fill.get("liquidity") or fill.get("liquiditySide") or liquidity

        avg_price = total_usd / total_size if total_size > 0 else 0.0

        # Fallback: indexer (especially testnet) often omits fee data.
        # If fee_total is zero but we have a real fill, estimate taker fee.
        fee_estimated = False
        if total_fee == 0.0 and total_usd > 0.0:
            total_fee = total_usd * TAKER_FEE_BPS
            fee_estimated = True

        return {
            "found": True,
            "status_label": "FILLED" if total_size > 0 else "BEST_EFFORT_OPENED",
            "raw_status": "FILLED" if total_size > 0 else "BEST_EFFORT_OPENED",
            "filled_size": total_size,
            "filled_usd_est": total_usd,
            "fee_total": total_fee,
            "fee_estimated": fee_estimated,
            "liquidity": liquidity,
            "server_order_id": None,
            "avg_price": avg_price,
        }

    orders_candidates = []
    try:
        orders_resp = await indexer.account.get_subaccount_orders(
            address=WALLET_ADDRESS.strip(),
            subaccount_number=0,
            ticker=market,
            limit=max_fill_lookback,
        )
        orders = orders_resp if isinstance(orders_resp, list) else orders_resp.get("orders", [])
        orders_candidates.extend(orders)
    except Exception:
        pass

    try:
        orders_resp = await indexer.account.get_subaccount_orders(
            address=WALLET_ADDRESS.strip(),
            subaccount_number=0,
            limit=max_fill_lookback,
        )
        orders = orders_resp if isinstance(orders_resp, list) else orders_resp.get("orders", [])
        orders_candidates.extend(orders)
    except Exception:
        pass

    seen = set()
    deduped_orders = []
    for order in orders_candidates:
        key = str(order.get("id") or "") + "|" + str(order.get("clientId") or "")
        if key not in seen:
            seen.add(key)
            deduped_orders.append(order)

    for order in deduped_orders:
        if _extract_cid(order) != cid:
            continue

        raw_status = str(order.get("status") or "UNKNOWN").upper()
        original_size = _sf(order.get("size", 0))
        remaining = _sf(order.get("remainingSize", 0))
        avg_price = _sf(
            order.get("averageFilledPrice")
            or order.get("avgFillPrice")
            or order.get("price")
            or 0.0
        )

        filled_size = _sf(
            order.get("totalFilled")
            or order.get("filledSize")
            or order.get("sizeFilled")
            or max(0.0, original_size - remaining)
        )

        fee_total = _sf(order.get("fee") or order.get("feeAmount") or order.get("feeUsd") or 0.0)
        filled_usd = filled_size * avg_price

        # Fallback: estimate taker fee when indexer omits fee data
        fee_estimated = False
        if fee_total == 0.0 and filled_usd > 0.0:
            fee_total = filled_usd * TAKER_FEE_BPS
            fee_estimated = True

        if raw_status == "FILLED":
            status_label = "FILLED"
        elif raw_status == "CANCELED" and filled_size > 0:
            status_label = "PARTIALLY_FILLED_IOC"
        elif raw_status == "CANCELED" and filled_size <= 0:
            status_label = "KILLED_BY_FOK"
        elif raw_status in ("OPEN", "PENDING") and filled_size > 0:
            status_label = "BEST_EFFORT_OPENED"
        else:
            status_label = raw_status

        return {
            "found": True,
            "status_label": status_label,
            "raw_status": raw_status,
            "filled_size": filled_size,
            "filled_usd_est": filled_usd,
            "fee_total": fee_total,
            "fee_estimated": fee_estimated,
            "liquidity": order.get("liquidity") or order.get("liquiditySide"),
            "server_order_id": order.get("id"),
            "avg_price": avg_price,
        }

    return {
        "found": False,
        "status_label": "NOT_FOUND",
        "raw_status": "NOT_FOUND",
        "filled_size": 0.0,
        "filled_usd_est": 0.0,
        "fee_total": 0.0,
        "liquidity": None,
        "server_order_id": None,
        "avg_price": 0.0,
    }


# ---------------------------------------------------------------------------
# Abort / Close everything
# ---------------------------------------------------------------------------

async def abort_all_positions(node, indexer, max_rounds=3, ignore_markets=None):
    """
    Cierra posiciones, pero NO se queda bucleado.
    Si después de max_rounds siguen abiertas, las reporta y sigue.
    """
    import json
    import asyncio
    from dydx_v4_client.wallet import Wallet
    from v4_proto.dydxprotocol.clob.order_pb2 import Order
    from constants import API_KEY, WALLET_ADDRESS

    ignore_markets = set(ignore_markets or [])

    wallet = await Wallet.from_mnemonic(node, API_KEY.strip(), WALLET_ADDRESS.strip())

    async def get_live_positions():
        account_resp = await indexer.account.get_subaccount(WALLET_ADDRESS.strip(), 0)
        sub = account_resp.get("subaccount", {}) or {}
        positions = sub.get("openPerpetualPositions", {}) or sub.get("perpetualPositions", {}) or {}

        live = {}
        for market, p in positions.items():
            size = _sf(p.get("size", 0))
            if abs(size) > 0:
                live[market] = size
        return live

    print("[ABORT] Starting bounded close...")

    # Fetch oracle prices once per round for limit-price calculation.
    async def get_oracle_prices():
        try:
            resp = await indexer.markets.get_perpetual_markets()
            mdata = resp.get("markets", {}) or {}
            return {m: _sf(v.get("oraclePrice")) for m, v in mdata.items()}
        except Exception:
            return {}

    for round_i in range(1, int(max_rounds) + 1):
        live = await get_live_positions()
        oracles = await get_oracle_prices()

        live_to_close = {
            m: s for m, s in live.items()
            if m not in ignore_markets
        }

        if not live_to_close:
            print("[ABORT] No closable open positions left.")
            break

        print(f"[ABORT] Round {round_i}/{max_rounds}: closing {len(live_to_close)} positions...")

        for market, size in live_to_close.items():
            side = "SELL" if size > 0 else "BUY"
            qty = abs(size)

            oracle = oracles.get(market, 0.0)
            if oracle <= 0:
                print(f"[ABORT] No oracle price for {market}, skipping.")
                continue

            # For IOC orders the "price" is the worst acceptable fill price.
            # BUY to close short → accept up to 10% above oracle.
            # SELL to close long → accept down to 10% below oracle.
            slippage = 0.10
            price = oracle * (1 + slippage) if side == "BUY" else oracle * (1 - slippage)

            try:
                await place_market_order(
                    node=node,
                    indexer=indexer,
                    wallet=wallet,
                    market=market,
                    side=side,
                    size=qty,
                    price=price,
                    reduce_only=True,
                    time_in_force_type=Order.TimeInForce.TIME_IN_FORCE_IOC,
                )
                print(f"[ABORT] Sent close {market} size={qty} side={side} price≤{price:.4f}")
            except Exception as e:
                print(f"[ABORT] Close failed {market}: {e}")

            await asyncio.sleep(0.75)

        await asyncio.sleep(2.0)

    remaining = await get_live_positions()

    ignored = {
        m: s for m, s in remaining.items()
        if m in ignore_markets
    }

    stuck = {
        m: s for m, s in remaining.items()
        if m not in ignore_markets
    }

    if stuck:
        print(f"[ABORT] WARNING: still open after {max_rounds} rounds:")
        for m, s in stuck.items():
            print(f"  - {m}: {s}")

    if ignored:
        print("[ABORT] Ignored positions:")
        for m, s in ignored.items():
            print(f"  - {m}: {s}")

    try:
        _json_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_agents.json")
        with open(_json_path, "w") as f:
            json.dump([], f, indent=2)
        print("[ABORT] bot_agents.json cleared.")
    except Exception as e:
        print(f"[ABORT] Could not clear bot_agents.json: {e}")

    print("[ABORT] Done. Continuing program.")
    return {
        "remaining": remaining,
        "ignored": ignored,
        "stuck": stuck,
    }

async def wait_order_visible(indexer, client_id: str, max_wait_s=6.0):
    cid = str(client_id)
    deadline = asyncio.get_event_loop().time() + float(max_wait_s)

    while asyncio.get_event_loop().time() < deadline:
        try:
            resp = await indexer.account.get_subaccount_orders(
                address=WALLET_ADDRESS.strip(),
                subaccount_number=0,
                limit=100
            )
            orders = resp if isinstance(resp, list) else resp.get("orders", [])
            for o in orders:
                if str(o.get("clientId")) == cid:
                    return True
        except Exception:
            pass

        await asyncio.sleep(0.5)

    return False