import pandas as pd
import numpy as np
import asyncio
import time

from func_utils import get_ISO_times
from constants import RESOLUTION
from pprint import pprint

# Get relevant time periods for ISO from and to
ISO_TIMES = get_ISO_times()

# Get Candles recent
async def get_candles_recent(indexer, market):
    """
    Returns a numpy float64 array of recent close prices (oldest first).
    Returns empty array on error or if the market has no data.
    Never raises.
    """
    # Protect API
    await asyncio.sleep(0.2)

    try:
        candles_resp = await indexer.markets.get_perpetual_market_candles(
            market=market,
            resolution=RESOLUTION,
            limit=100
        )
    except Exception as e:
        print(f"[PUBLIC] get_candles_recent error for {market}: {e}", flush=True)
        return np.array([], dtype=np.float64)

    # Defensively handle missing/malformed response
    if not isinstance(candles_resp, dict):
        return np.array([], dtype=np.float64)

    raw = candles_resp.get("candles")
    if not raw or not isinstance(raw, list):
        return np.array([], dtype=np.float64)

    close_prices = []
    for candle in raw:
        try:
            close_prices.append(float(candle["close"]))
        except Exception:
            continue

    if not close_prices:
        return np.array([], dtype=np.float64)

    close_prices.reverse()  # chronological order
    return np.array(close_prices, dtype=np.float64)


# Get Candles Historical
async def get_candles_historical(indexer, market):

    # Define output
    close_prices = []

    # Extract historical price data for each timeframe
    for timeframe in ISO_TIMES.keys():

        # Confirm times needed
        tf_obj = ISO_TIMES[timeframe]
        from_iso = tf_obj["from_iso"]
        to_iso = tf_obj["to_iso"]

        # Protect API
        await asyncio.sleep(0.2)

        # Get data
        candles = await indexer.markets.get_perpetual_market_candles(
            market=market,
            resolution=RESOLUTION,
            from_iso=from_iso,
            to_iso=to_iso,
            limit=100
        )

        # Structure data
        for candle in candles["candles"]:
            close_prices.append({"datetime": candle["startedAt"],market: candle["close"]})

        # Construct and return DataFrame
    close_prices.reverse()
    return close_prices



# Get bid-ask spread in basis points for a single market
async def get_market_spread_bps(indexer, market):
    """
    Fetches the best bid and ask from the live orderbook and returns the
    spread expressed in basis points: (ask - bid) / mid * 10_000.

    Returns None on any error so the caller can treat it as "proceed".
    A None result must never block a trade — it just means data unavailable.
    """
    try:
        ob = await indexer.markets.get_perpetual_market_orderbook(market=market)
        asks = ob.get("asks", []) if isinstance(ob, dict) else []
        bids = ob.get("bids", []) if isinstance(ob, dict) else []
        if not asks or not bids:
            return None
        best_ask = float(asks[0].get("price", 0) if isinstance(asks[0], dict) else asks[0])
        best_bid = float(bids[0].get("price", 0) if isinstance(bids[0], dict) else bids[0])
        if best_ask <= 0 or best_bid <= 0 or best_bid >= best_ask:
            return None
        mid = (best_ask + best_bid) / 2.0
        return ((best_ask - best_bid) / mid) * 10_000.0
    except Exception:
        return None


# Construct market prices
async def construct_market_prices(node, indexer):

    # Declare variables
    tradeable_markets =[]
    markets= await indexer.markets.get_perpetual_markets()
    market_data = markets.get("markets", {})

    # Find tradeable pais
    for market_id in market_data.keys():
        market_info = market_data[market_id]
        if market_info.get("status")=="ACTIVE":
            tradeable_markets.append(market_id)

    print(f"{len(tradeable_markets)} active markets found.")

    # Set initial DateFrame
    if tradeable_markets:
        close_prices = await get_candles_historical(indexer, tradeable_markets[0])
        df = pd.DataFrame(close_prices)
        df.set_index("datetime", inplace=True)

        # Append other prices to DataFrame
        # You can limit the amount to loop through here to save time in development UAT
        for market in tradeable_markets[1:]:
            try:
                close_prices_add = await get_candles_historical(indexer, market)
                if not close_prices_add or len(close_prices_add) < 10:
                    continue
                df_add = pd.DataFrame(close_prices_add)
                df_add.set_index("datetime", inplace=True)
                df_add = df_add.astype(float)

                if df_add[market].std() == 0:
                    print(f"   ⚠️ Saltando {market}: Sin movimiento de precio.")
                    continue

                df = pd.merge(df, df_add, how="outer", on="datetime",copy=False)
            except Exception as e:
                print(f"Error calculating cointegration results: {e}")
                continue

        # Check any columns with NaNs
        df = df.astype(float)
        nans = df.columns[df.isna().any()].tolist()
        if len(nans)>0:
            df.drop(columns=nans, inplace=True)

        print(f"✅ Tabla final lista con {len(df.columns)} mercados seleccionados.")

        # Return result
        return df



