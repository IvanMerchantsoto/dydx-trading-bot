import asyncio
import os
import time

from func_connections import connect_dydx
from func_private import abort_all_positions
from func_public import construct_market_prices
from func_entry_pairs import open_positions
from func_cointegration import store_cointegration_results, CSV_PATH as COINT_CSV_PATH
from func_exit_pairs import manage_trade_exits
from func_kpis import send_account_kpis
from func_risk_off import risk_off_close_worst_pair
from func_messaging import send_message
from func_logging import log_event

from constants import (
    ABORT_ALL_POSITIONS,
    FIND_COINTEGRATED,
    PLACE_TRADES,
    MANAGE_EXITS,
    EXIT_CHECK_SECONDS,
    KPI_SECONDS,
    BATCH_OPEN_TRADES,
    MAX_OPEN_TRADES,
    RISK_OFF_ENABLED,
    RISK_OFF_FREE_COLLATERAL_TRIGGER,
    RISK_OFF_FORCE_IF_OPEN_TRADES_GE,
    COINTEGRATION_REFRESH_HOURS,
    UNMANAGED_IGNORE_MARKETS,
)


def _csv_needs_refresh() -> bool:
    if COINTEGRATION_REFRESH_HOURS <= 0:
        return False
    if not os.path.exists(COINT_CSV_PATH):
        return True
    age_hours = (time.time() - os.path.getmtime(COINT_CSV_PATH)) / 3600.0
    return age_hours >= float(COINTEGRATION_REFRESH_HOURS)


async def _run_cointegration(node, indexer):
    print("Fetching market prices for cointegration, please allow 3 minutes...", flush=True)
    send_message("🔄 Refreshing cointegrated pairs (this takes ~3 min)...")
    df_market_prices = await construct_market_prices(node, indexer)
    try:
        _pkl = os.path.join(os.path.dirname(os.path.abspath(__file__)), "market_prices.pkl")
        df_market_prices.to_pickle(_pkl)
    except Exception:
        pass
    result = store_cointegration_results(df_market_prices)
    if result != "saved":
        raise RuntimeError("store_cointegration_results did not return 'saved'")
    log_event({"type": "cointegration_refresh_done", "csv": COINT_CSV_PATH})
    send_message("✅ Cointegrated pairs refreshed.")


async def main():
    send_message("Bot Launched Successfully")

    try:
        print("Connecting to client...", flush=True)
        node, indexer, wallet = await connect_dydx()
    except Exception as e:
        print("Error connecting to client:", e, flush=True)
        send_message("Failed to connect to DYDX.")
        raise

    if ABORT_ALL_POSITIONS:
        try:
            print("Closing all positions...", flush=True)
            # Pass ignore_markets so stuck testnet positions are skipped
            await abort_all_positions(
                node, indexer,
                ignore_markets=UNMANAGED_IGNORE_MARKETS,
            )
        except Exception as e:
            print("Error closing all positions:", e, flush=True)
            send_message("Failed to abort all positions.")
            raise

    if FIND_COINTEGRATED or _csv_needs_refresh():
        reason = "FIND_COINTEGRATED=True" if FIND_COINTEGRATED else f"CSV stale/missing (>{COINTEGRATION_REFRESH_HOURS}h)"
        print(f"[COINT] Running cointegration scan. Reason: {reason}", flush=True)
        try:
            await _run_cointegration(node, indexer)
        except Exception as e:
            print(f"Error cointegrating pairs: {e}", flush=True)
            send_message(f"⚠️ Failed to refresh cointegrated pairs: {e}")
            if not os.path.exists(COINT_CSV_PATH):
                raise

    loop = asyncio.get_event_loop()

    opened_since_exit = 0
    last_kpi_ts = loop.time()
    last_coint_refresh_ts = loop.time()

    while True:
        now = loop.time()
        print("[D1] loop top", flush=True)

        # ── Periodic cointegration refresh ────────────────────────────────────
        print("[D2] coint check", flush=True)
        if COINTEGRATION_REFRESH_HOURS > 0:
            elapsed_coint = (now - last_coint_refresh_ts) / 3600.0
            if elapsed_coint >= float(COINTEGRATION_REFRESH_HOURS):
                print(f"[D2] refreshing coint ({elapsed_coint:.1f}h old)", flush=True)
                try:
                    await _run_cointegration(node, indexer)
                    last_coint_refresh_ts = loop.time()
                except Exception as e_coint:
                    print(f"[D2] coint refresh error: {e_coint}", flush=True)
                    last_coint_refresh_ts = loop.time()

        # ── Manage exits ──────────────────────────────────────────────────────
        print(f"[D3] MANAGE_EXITS={MANAGE_EXITS}", flush=True)
        if MANAGE_EXITS:
            try:
                print("[D3] calling manage_trade_exits...", flush=True)
                await manage_trade_exits(node, indexer, wallet)
                print("[D3] manage_trade_exits done", flush=True)
            except Exception as e:
                print(f"[D3] exits error: {e}", flush=True)

        # ── KPIs ──────────────────────────────────────────────────────────────
        print(f"[D4] KPI check (elapsed={(now-last_kpi_ts):.0f}s / {KPI_SECONDS}s)", flush=True)
        if now - last_kpi_ts >= KPI_SECONDS:
            try:
                snapshot = await send_account_kpis(indexer)
                last_kpi_ts = now
                if RISK_OFF_ENABLED and snapshot and snapshot.get("free", 0) < float(RISK_OFF_FREE_COLLATERAL_TRIGGER):
                    await risk_off_close_worst_pair(node, indexer, wallet)
            except Exception as e:
                print(f"[D4] KPI error: {e}", flush=True)
                last_kpi_ts = now

        # ── Place trades ──────────────────────────────────────────────────────
        print(f"[D5] PLACE_TRADES={PLACE_TRADES}", flush=True)
        if PLACE_TRADES:
            print("[D5] entering PLACE_TRADES block", flush=True)
            try:
                import json as _json
                _json_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_agents.json")
                print(f"[D5] reading JSON from {_json_path}", flush=True)
                try:
                    with open(_json_path) as _f:
                        _records = _json.load(_f)
                    open_pairs = len([r for r in _records if isinstance(r, dict)])
                except Exception as je:
                    print(f"[D5] JSON read error: {je}", flush=True)
                    open_pairs = 0

                print(f"[D5] open_pairs={open_pairs} max={MAX_OPEN_TRADES} batch={opened_since_exit}/{BATCH_OPEN_TRADES}", flush=True)

                if open_pairs >= MAX_OPEN_TRADES:
                    print("[D5] at cap — skipping open", flush=True)
                    if RISK_OFF_ENABLED and open_pairs >= RISK_OFF_FORCE_IF_OPEN_TRADES_GE:
                        await risk_off_close_worst_pair(node, indexer, wallet)
                else:
                    remaining_capacity = max(0, MAX_OPEN_TRADES - open_pairs)
                    remaining_in_batch = min(
                        max(0, BATCH_OPEN_TRADES - opened_since_exit),
                        remaining_capacity,
                    )
                    print(f"[D5] remaining_in_batch={remaining_in_batch}", flush=True)

                    if remaining_in_batch > 0:
                        print("[D5] calling open_positions...", flush=True)
                        opened_now = await open_positions(
                            node, indexer, wallet,
                            max_new_trades=remaining_in_batch,
                        )
                        print(f"[D5] open_positions returned {opened_now}", flush=True)
                        opened_since_exit += int(opened_now or 0)

                    if opened_since_exit >= BATCH_OPEN_TRADES:
                        if MANAGE_EXITS:
                            await manage_trade_exits(node, indexer, wallet)
                        opened_since_exit = 0

            except Exception as e:
                print(f"[D5] PLACE_TRADES exception: {e}", flush=True)
                import traceback; traceback.print_exc()

        print(f"[D6] sleeping {EXIT_CHECK_SECONDS}s", flush=True)
        await asyncio.sleep(EXIT_CHECK_SECONDS)


if __name__ == "__main__":
    asyncio.run(main())
