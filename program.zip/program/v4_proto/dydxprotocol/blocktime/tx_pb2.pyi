from v4_proto.cosmos_proto import cosmos_pb2 as _cosmos_pb2
from v4_proto.cosmos.msg.v1 import msg_pb2 as _msg_pb2
from v4_proto.dydxprotocol.blocktime import params_pb2 as _params_pb2
from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MsgUpdateDowntimeParams(_message.Message):
    __slots__ = ("authority", "params")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    params: _params_pb2.DowntimeParams
    def __init__(self, authority: _Optional[str] = ..., params: _Optional[_Union[_params_pb2.DowntimeParams, _Mapping]] = ...) -> None: ...

class MsgUpdateDowntimeParamsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgUpdateSynchronyParams(_message.Message):
    __slots__ = ("authority", "params")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    params: _params_pb2.SynchronyParams
    def __init__(self, authority: _Optional[str] = ..., params: _Optional[_Union[_params_pb2.SynchronyParams, _Mapping]] = ...) -> None: ...

class MsgUpdateSynchronyParamsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
